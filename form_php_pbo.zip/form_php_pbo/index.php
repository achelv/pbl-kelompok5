<?php
class User {
    public $firstname;
    public $lastname;
    public $phone;
    public $address;

    public function __construct($firstname, $lastname, $phone, $address) {
        $this->firstname = htmlspecialchars($firstname);
        $this->lastname = htmlspecialchars($lastname);
        $this->phone = htmlspecialchars($phone);
        $this->address = htmlspecialchars($address);
    }

    public function tampil() {
        return "Hi, my name is <b>{$this->firstname} {$this->lastname}</b><br>
                Phone Number: {$this->phone}<br>
                Address: {$this->address}";
    }
}

$result = "";
if (isset($_POST['submit'])) {
    $user = new User(
        $_POST['firstname'],
        $_POST['lastname'],
        $_POST['phone'],
        $_POST['address']
    );
    $result = $user->tampil();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Form Sederhana</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            background: white;
            width: 350px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            text-align: center;
        }

        h2 {
            margin-bottom: 15px;
            color: #333;
        }

        input, textarea {
            width: 100%;
            padding: 8px;
            margin: 6px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        textarea {
            height: 60px;
            resize: none;
        }

        button {
            margin-top: 10px;
            width: 100%;
            padding: 10px;
            background: #4da3ff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #2d8cf0;
        }

        .result {
            margin-top: 15px;
            text-align: left;
            font-size: 14px;
            color: #333;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Simple Form</h2>

    <form method="POST">
        <input type="text" name="firstname" placeholder="First Name" required>
        <input type="text" name="lastname" placeholder="Last Name" required>
        <input type="text" name="phone" placeholder="Phone Number" required>
        <textarea name="address" placeholder="Address" required></textarea>

        <button type="submit" name="submit">Submit</button>
    </form>

    <div class="result">
        <?php
        if ($result != "") {
            echo "<hr>" . $result;
        }
        ?>
    </div>
</div>

</body>
</html>